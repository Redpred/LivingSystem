package com.livingsystem.client.screen;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Shared rendering and hit-testing for the two-tab bar that sits just above the inventory / health
 * windows. Texture-free: icons are drawn with filled rectangles so the mod works without art
 * assets.
 *
 * <p>Tab 0 = inventory, tab 1 = health. Coordinates are given as the GUI window's top-left corner
 * ({@code guiLeft}, {@code guiTop}); the tabs are drawn above that edge.</p>
 */
public final class InventoryTabs {

    public static final int TAB_INVENTORY = 0;
    public static final int TAB_HEALTH = 1;

    public static final int TAB_W = 26;
    public static final int TAB_H = 24;
    private static final int GAP = 2;
    private static final int OFFSET_X = 4;

    private static final int COLOR_BORDER = 0xFF000000;
    private static final int COLOR_SELECTED = 0xFFC6C6C6;
    private static final int COLOR_UNSELECTED = 0xFF8B8B8B;
    private static final int COLOR_HOVER = 0xFFFFFFFF;

    private InventoryTabs() {
    }

    private static int tabX(int guiLeft, int index) {
        return guiLeft + OFFSET_X + index * (TAB_W + GAP);
    }

    private static int tabY(int guiTop) {
        return guiTop - TAB_H + 3;
    }

    public static void render(GuiGraphics graphics, int guiLeft, int guiTop, int selected, int mouseX, int mouseY) {
        for (int i = 0; i < 2; i++) {
            int x = tabX(guiLeft, i);
            int y = tabY(guiTop);
            boolean isSelected = i == selected;
            boolean hovered = mouseX >= x && mouseX < x + TAB_W && mouseY >= y && mouseY < y + TAB_H;

            // Selected tab extends a couple of pixels lower to visually merge with the window.
            int bottom = y + TAB_H + (isSelected ? 2 : 0);
            graphics.fill(x, y, x + TAB_W, bottom, hovered ? COLOR_HOVER : COLOR_BORDER);
            int fill = isSelected ? COLOR_SELECTED : COLOR_UNSELECTED;
            graphics.fill(x + 1, y + 1, x + TAB_W - 1, bottom - 1, fill);

            if (i == TAB_INVENTORY) {
                drawInventoryIcon(graphics, x, y);
            } else {
                drawHealthIcon(graphics, x, y);
            }
        }
    }

    /** Returns the tab index under the cursor, or -1. */
    public static int tabAt(int guiLeft, int guiTop, double mouseX, double mouseY) {
        int y = tabY(guiTop);
        for (int i = 0; i < 2; i++) {
            int x = tabX(guiLeft, i);
            if (mouseX >= x && mouseX < x + TAB_W && mouseY >= y && mouseY < y + TAB_H) {
                return i;
            }
        }
        return -1;
    }

    /** A small 2x2 grid suggesting inventory slots. */
    private static void drawInventoryIcon(GuiGraphics graphics, int tabX, int tabY) {
        int cx = tabX + TAB_W / 2;
        int cy = tabY + TAB_H / 2;
        int s = 4;
        int g = 1;
        int color = 0xFF402810;
        for (int dx = 0; dx < 2; dx++) {
            for (int dy = 0; dy < 2; dy++) {
                int x = cx - s - g + dx * (s + g);
                int y = cy - s - g + dy * (s + g);
                graphics.fill(x, y, x + s, y + s, color);
            }
        }
    }

    /** A red medical cross suggesting health. */
    private static void drawHealthIcon(GuiGraphics graphics, int tabX, int tabY) {
        int cx = tabX + TAB_W / 2;
        int cy = tabY + TAB_H / 2;
        int arm = 6;
        int half = 2;
        int color = 0xFFD03030;
        graphics.fill(cx - half, cy - arm, cx + half, cy + arm, color); // vertical bar
        graphics.fill(cx - arm, cy - half, cx + arm, cy + half, color); // horizontal bar
    }
}
