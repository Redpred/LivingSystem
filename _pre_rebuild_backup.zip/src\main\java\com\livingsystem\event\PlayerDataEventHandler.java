package com.livingsystem.event;

import com.livingsystem.LivingSystem;
import com.livingsystem.body.PlayerHealthData;
import com.livingsystem.network.ModNetworking;
import com.livingsystem.registry.ModAttachments;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/**
 * Keeps the per-body-part health data consistent across the player lifecycle and ensures the
 * client always has an up-to-date copy for the UI.
 *
 * <ul>
 *     <li><b>Login / respawn</b> — push the current data to the client.</li>
 *     <li><b>Clone (dimension change)</b> — carry the data over; on death the new player keeps the
 *     default (fully healed) data, mirroring vanilla health resetting on respawn.</li>
 * </ul>
 */
@EventBusSubscriber(modid = LivingSystem.MOD_ID)
public final class PlayerDataEventHandler {

    private PlayerDataEventHandler() {
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ModNetworking.sendTo(player, player.getData(ModAttachments.PLAYER_HEALTH.get()));
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ModNetworking.sendTo(player, player.getData(ModAttachments.PLAYER_HEALTH.get()));
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (event.isWasDeath()) {
            return; // died: leave the (default, fully-healed) data on the new player
        }
        // Dimension change / end-portal return: carry the existing data across.
        PlayerHealthData original = event.getOriginal().getData(ModAttachments.PLAYER_HEALTH.get());
        event.getEntity().setData(ModAttachments.PLAYER_HEALTH.get(), new PlayerHealthData(original));
    }
}
