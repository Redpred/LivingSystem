package com.livingsystem.data;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.livingsystem.LivingSystem;
import com.livingsystem.body.BodyDamageRule;
import com.mojang.serialization.JsonOps;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.AddReloadListenerEvent;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;

/**
 * Server-side store of datapack-defined {@link BodyDamageRule}s, loaded from
 * {@code data/<namespace>/body_damage/*.json} and reloaded on {@code /reload}.
 *
 * <p>Rules are keyed by the damage source's {@link net.minecraft.world.damagesource.DamageSource#getMsgId() msgId}
 * (lower-cased), which is also the JSON file name. Routing happens only on the server, so these
 * rules are never synced to the client.</p>
 */
public class BodyDamageRules extends SimpleJsonResourceReloadListener {

    private static final Gson GSON = new Gson();
    public static final String DIRECTORY = "body_damage";

    /** Replaced wholesale on each reload; read from the server thread during damage handling. */
    private static volatile Map<String, BodyDamageRule> rules = Map.of();

    public BodyDamageRules() {
        super(GSON, DIRECTORY);
    }

    /** Rule for a damage source's msgId, or {@code null} if none is defined (caller falls back). */
    @Nullable
    public static BodyDamageRule get(String damageSourceMsgId) {
        return rules.get(damageSourceMsgId.toLowerCase());
    }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> object, ResourceManager resourceManager, ProfilerFiller profiler) {
        Map<String, BodyDamageRule> loaded = new HashMap<>();
        object.forEach((location, json) -> BodyDamageRule.CODEC
                .parse(JsonOps.INSTANCE, json)
                .resultOrPartial(error -> LivingSystem.LOGGER.error("Failed to parse body_damage rule {}: {}", location, error))
                .ifPresent(rule -> loaded.put(location.getPath().toLowerCase(), rule)));
        rules = Map.copyOf(loaded);
        LivingSystem.LOGGER.info("Loaded {} body_damage rule(s).", rules.size());
    }

    /** Registers the reload listener with the server's data-pack reload manager. */
    @EventBusSubscriber(modid = LivingSystem.MOD_ID)
    public static final class Registration {

        private Registration() {
        }

        @SubscribeEvent
        public static void onAddReloadListener(AddReloadListenerEvent event) {
            event.addListener(new BodyDamageRules());
        }
    }
}
