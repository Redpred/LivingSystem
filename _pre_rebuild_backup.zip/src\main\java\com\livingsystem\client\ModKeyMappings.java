package com.livingsystem.client;

import com.livingsystem.LivingSystem;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

/**
 * Client key bindings for the mod.
 *
 * <p>Registering through {@link RegisterKeyMappingsEvent} makes the binding appear in
 * Options -> Controls under the mod's own category, where the player can freely rebind it.</p>
 */
@EventBusSubscriber(modid = LivingSystem.MOD_ID, value = Dist.CLIENT)
public final class ModKeyMappings {

    /** Category shown in the Controls screen; the value is a translation key. */
    public static final String CATEGORY = "key.categories.livingsystem";

    /** Opens the health panel. Defaults to H. */
    public static final KeyMapping OPEN_HEALTH = new KeyMapping(
            "key.livingsystem.open_health",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_H,
            CATEGORY);

    private ModKeyMappings() {
    }

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) {
        event.register(OPEN_HEALTH);
    }
}
