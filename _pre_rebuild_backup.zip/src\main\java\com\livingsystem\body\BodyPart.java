package com.livingsystem.body;

import java.util.List;

/**
 * The eight body parts that the LivingSystem health model is divided into.
 *
 * <p>Inspired by extraction-shooter (Tarkov-like) health systems: every incoming hit is
 * attributed to one or more of these parts, and each part tracks its own health pool. The pools
 * are <em>authoritative</em> — the vanilla heart bar is derived from them (see
 * {@link PlayerHealthData}) and the player dies the moment a {@linkplain #isVital() vital} part
 * (head or torso) is destroyed.</p>
 *
 * <p>The {@code ordinal()} of each constant is the stable index into the {@code float[]} stored in
 * {@link PlayerHealthData} and sent over the network, so the declaration order must not change.
 * The feet were added after the original six parts specifically so existing saves (six values)
 * keep mapping onto head/torso/arms/legs unchanged.</p>
 */
public enum BodyPart {
    HEAD("head", 35.0F),
    TORSO("torso", 85.0F),
    LEFT_ARM("left_arm", 60.0F),
    RIGHT_ARM("right_arm", 60.0F),
    LEFT_LEG("left_leg", 65.0F),
    RIGHT_LEG("right_leg", 65.0F),
    LEFT_FOOT("left_foot", 40.0F),
    RIGHT_FOOT("right_foot", 40.0F);

    /** Cached array to avoid the allocation that {@link #values()} performs on every call. */
    public static final BodyPart[] VALUES = values();
    public static final int COUNT = VALUES.length;

    private final String id;
    private final float maxHealth;

    BodyPart(String id, float maxHealth) {
        this.id = id;
        this.maxHealth = maxHealth;
    }

    public String getId() {
        return id;
    }

    public float getMaxHealth() {
        return maxHealth;
    }

    /**
     * Vital parts gate the player's life: when a vital part's pool reaches zero the player dies.
     * Non-vital parts being destroyed only causes debuffs / bleeding.
     */
    public boolean isVital() {
        return this == HEAD || this == TORSO;
    }

    /**
     * Adjacent parts that excess damage spills into when this part's pool is exhausted (one hop).
     * The topology mirrors a humanoid silhouette so a destroyed limb bleeds into the part it
     * connects to (e.g. an arm into the torso, a foot into its leg).
     */
    public List<BodyPart> neighbours() {
        return switch (this) {
            case HEAD, LEFT_ARM, RIGHT_ARM -> List.of(TORSO);
            case TORSO -> List.of(HEAD, LEFT_ARM, RIGHT_ARM, LEFT_LEG, RIGHT_LEG);
            case LEFT_LEG -> List.of(TORSO, RIGHT_LEG, LEFT_FOOT);
            case RIGHT_LEG -> List.of(TORSO, LEFT_LEG, RIGHT_FOOT);
            case LEFT_FOOT -> List.of(LEFT_LEG, RIGHT_FOOT);
            case RIGHT_FOOT -> List.of(RIGHT_LEG, LEFT_FOOT);
        };
    }

    /** Translation key for the human-readable name of this body part. */
    public String translationKey() {
        return "livingsystem.body_part." + id;
    }
}
