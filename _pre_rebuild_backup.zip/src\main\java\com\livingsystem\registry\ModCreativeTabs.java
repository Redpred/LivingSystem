package com.livingsystem.registry;

import com.livingsystem.LivingSystem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Registers the mod's creative-mode tab and populates it with the mod's items.
 */
public final class ModCreativeTabs {

    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LivingSystem.MOD_ID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> LIVING_SYSTEM_TAB =
            CREATIVE_MODE_TABS.register("living_system_tab", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.livingsystem"))
                    .icon(() -> new ItemStack(ModItems.EXAMPLE_ITEM.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.EXAMPLE_ITEM.get());
                        output.accept(ModBlocks.EXAMPLE_BLOCK.get());
                    })
                    .build());

    private ModCreativeTabs() {}

    public static void register(IEventBus eventBus) {
        CREATIVE_MODE_TABS.register(eventBus);
    }
}
