package com.livingsystem;

import com.livingsystem.registry.ModItems;
import com.livingsystem.registry.ModBlocks;
import com.livingsystem.registry.ModCreativeTabs;
import com.livingsystem.registry.ModAttachments;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

/**
 * Main entry point for the LivingSystem mod.
 *
 * <p>The {@link Mod} annotation tells the mod loader (FML) that this is the main mod class
 * for the mod with the given id. The id must match {@code mod_id} declared in
 * {@code neoforge.mods.toml} / {@code gradle.properties}.</p>
 */
@Mod(LivingSystem.MOD_ID)
public class LivingSystem {

    /** The mod id. Used everywhere a namespace is required (registries, resources, etc.). */
    public static final String MOD_ID = "livingsystem";

    /** Shared SLF4J logger for the mod. */
    public static final Logger LOGGER = LogUtils.getLogger();

    /**
     * The mod constructor is invoked by FML during mod loading. The {@link IEventBus} passed in
     * is the mod-specific event bus, used for registration and lifecycle events.
     */
    public LivingSystem(IEventBus modEventBus, ModContainer modContainer) {
        // Register the commonSetup method for mod loading
        modEventBus.addListener(this::commonSetup);

        // Register all deferred registers to the mod event bus
        ModItems.register(modEventBus);
        ModBlocks.register(modEventBus);
        ModCreativeTabs.register(modEventBus);
        ModAttachments.register(modEventBus);

        // Register ourselves for server and other game events we are interested in.
        // Note that this is necessary if and only if we want *this* class (LivingSystem) to respond
        // directly to events. Do not add this line if there are no @SubscribeEvent-annotated methods here.
        NeoForge.EVENT_BUS.register(this);

        // Register our mod's config so that FML can create and load the config file for us.
        modContainer.registerConfig(ModConfig.Type.COMMON, Config.SPEC);

        LOGGER.info("LivingSystem mod constructed.");
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        // Some common setup code that runs once during mod initialization.
        LOGGER.info("LivingSystem common setup complete.");
    }

    // You can use SubscribeEvent and let the Event Bus discover methods to call
    @net.neoforged.bus.api.SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        // Do something when the server starts
        LOGGER.info("LivingSystem: server starting.");
    }
}
