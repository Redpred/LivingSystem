package com.livingsystem.event;

import com.livingsystem.Config;
import com.livingsystem.LivingSystem;
import com.livingsystem.body.BodyPart;
import com.livingsystem.body.HealingRule;
import com.livingsystem.body.PlayerHealthData;
import com.livingsystem.data.HealingRules;
import com.livingsystem.network.HealLimbPayload;
import com.livingsystem.network.ModNetworking;
import com.livingsystem.registry.ModAttachments;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;
import net.neoforged.neoforge.event.level.SleepFinishedTimeEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Datapack-driven healing: consuming an item with a {@link HealingRule} heals body parts.
 *
 * <ul>
 *     <li>{@code ALL_BODY} rules heal every eligible part over time on use.</li>
 *     <li>{@code SINGLE_LIMB} rules grant a one-shot {@link PendingHeal} token and ask the client to
 *     open the health screen in heal mode; the limb the player clicks comes back as a
 *     {@link HealLimbPayload}, validated here against that token (so heal values are never trusted
 *     from the client).</li>
 * </ul>
 * Also restores parts after a full night's sleep. Destroyed (0-health) parts are only healed when
 * the rule is flagged {@code restores_destroyed}.
 */
@EventBusSubscriber(modid = LivingSystem.MOD_ID)
public final class HealingHandler {

    /** One-shot single-limb heal credits granted on item use, consumed by the heal-limb packet. */
    private static final Map<UUID, PendingHeal> PENDING = new ConcurrentHashMap<>();

    private HealingHandler() {
    }

    private record PendingHeal(float value, int time, boolean restoresDestroyed) {
    }

    @SubscribeEvent
    public static void onFinishUsingItem(LivingEntityUseItemEvent.Finish event) {
        if (!Config.ENABLE_LIVING_SYSTEM.get() || !(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        ResourceLocation itemId = BuiltInRegistries.ITEM.getKey(event.getItem().getItem());
        HealingRule rule = HealingRules.get(itemId);
        if (rule == null) {
            return;
        }

        float value = (float) Math.min(rule.healValue(), Config.HEAL_VALUE_MAX.get());
        if (rule.isSingleLimb()) {
            PENDING.put(player.getUUID(), new PendingHeal(value, rule.healTime(), rule.restoresDestroyed()));
            ModNetworking.sendOpenHealScreen(player, rule.restoresDestroyed());
        } else {
            PlayerHealthData data = player.getData(ModAttachments.PLAYER_HEALTH.get());
            for (BodyPart part : BodyPart.VALUES) {
                if (data.getHealth(part) > 0 || rule.restoresDestroyed()) {
                    data.applyHealOverTime(part, value, rule.healTime());
                }
            }
            player.setData(ModAttachments.PLAYER_HEALTH.get(), data);
            ModNetworking.sendTo(player, data);
        }
    }

    /** Server handler for {@link HealLimbPayload}: applies the player's pending single-limb heal. */
    public static void handleHealLimb(HealLimbPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (!(context.player() instanceof ServerPlayer player)) {
                return;
            }
            PendingHeal pending = PENDING.remove(player.getUUID());
            if (pending == null) {
                return;
            }
            int ordinal = payload.partOrdinal();
            if (ordinal < 0 || ordinal >= BodyPart.COUNT) {
                return;
            }
            BodyPart part = BodyPart.VALUES[ordinal];

            PlayerHealthData data = player.getData(ModAttachments.PLAYER_HEALTH.get());
            if (data.getHealth(part) <= 0 && !pending.restoresDestroyed()) {
                return; // this treatment cannot restore a destroyed limb
            }
            data.applyHealOverTime(part, pending.value(), pending.time());
            player.setData(ModAttachments.PLAYER_HEALTH.get(), data);
            ModNetworking.sendTo(player, data);
        });
    }

    @SubscribeEvent
    public static void onSleepFinished(SleepFinishedTimeEvent event) {
        if (!Config.ENABLE_LIVING_SYSTEM.get()) {
            return;
        }
        double fraction = Config.SLEEP_HEAL_FRACTION.get();
        if (fraction <= 0 || !(event.getLevel() instanceof ServerLevel level)) {
            return;
        }
        for (ServerPlayer player : level.players()) {
            if (!player.isSleepingLongEnough()) {
                continue;
            }
            PlayerHealthData data = player.getData(ModAttachments.PLAYER_HEALTH.get());
            boolean changed = false;
            for (BodyPart part : BodyPart.VALUES) {
                float health = data.getHealth(part);
                if (health > 0 && health < part.getMaxHealth()) { // destroyed parts need treatment, not rest
                    data.heal(part, (float) (part.getMaxHealth() * fraction));
                    changed = true;
                }
            }
            if (changed) {
                player.setData(ModAttachments.PLAYER_HEALTH.get(), data);
                ModNetworking.sendTo(player, data);
            }
        }
    }
}
