package com.livingsystem.body;

import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Maps an incoming {@link DamageSource} to the single {@link BodyPart} most likely struck.
 *
 * <p>There is no vanilla notion of "where" a hit landed, so we reconstruct it geometrically from the
 * overlap between the victim and whatever dealt the damage:</p>
 * <ul>
 *     <li><b>Impact point</b> — for a projectile or a melee attacker, the centre of the intersection
 *     between the victim's bounding box and the attacker's/projectile's box. This is the point of
 *     contact, a good proxy for where on the body the blow landed.</li>
 *     <li><b>Vertical band</b> — the impact's height as a fraction of the victim's <em>current</em>
 *     bounding box (so crouching/swimming poses are handled automatically) selects
 *     feet / legs / torso-arms / head.</li>
 *     <li><b>Lateral offset</b> — the impact projected onto the victim's right-hand vector selects
 *     left/right and arm-vs-torso.</li>
 * </ul>
 *
 * <p>When nothing usable can be determined (environmental sources with no entity), a
 * silhouette-weighted random part is chosen. Adapted from LSO's {@code PlayerModelUtil}, simplified
 * to derive bands from the live bounding box rather than hard-coded per-pose boxes.</p>
 */
public final class BodyPartLocator {

    // Vertical band thresholds as a fraction of the victim's height (0 = feet, 1 = top of head).
    private static final double BAND_HEAD = 0.80;
    private static final double BAND_TORSO = 0.45;
    private static final double BAND_LEGS = 0.15;

    private BodyPartLocator() {
    }

    public static BodyPart locate(LivingEntity victim, DamageSource source) {
        RandomSource random = victim.getRandom();
        Vec3 impact = resolveImpact(victim, source);
        if (impact == null) {
            return randomBiased(random);
        }

        double height = Math.max(0.1, victim.getBbHeight());
        double frac = (impact.y - victim.getY()) / height;

        // Lateral offset of the impact projected onto the victim's right-hand vector.
        double yawRad = Math.toRadians(victim.getYRot());
        double rightX = -Math.cos(yawRad);
        double rightZ = -Math.sin(yawRad);
        double lateral = (impact.x - victim.getX()) * rightX + (impact.z - victim.getZ()) * rightZ;
        double shoulder = victim.getBbWidth() * 0.30;

        if (frac > BAND_HEAD) {
            return BodyPart.HEAD;
        }
        if (frac > BAND_TORSO) {
            if (Math.abs(lateral) > shoulder) {
                return lateral > 0 ? BodyPart.RIGHT_ARM : BodyPart.LEFT_ARM;
            }
            return BodyPart.TORSO;
        }
        if (frac > BAND_LEGS) {
            return sideOr(random, lateral, BodyPart.RIGHT_LEG, BodyPart.LEFT_LEG);
        }
        return sideOr(random, lateral, BodyPart.RIGHT_FOOT, BodyPart.LEFT_FOOT);
    }

    /** Picks a left/right part by lateral sign; near-centre hits fall back to a coin flip. */
    private static BodyPart sideOr(RandomSource random, double lateral, BodyPart right, BodyPart left) {
        if (Math.abs(lateral) < 1.0E-3) {
            return random.nextBoolean() ? right : left;
        }
        return lateral > 0 ? right : left;
    }

    /**
     * The point of contact for a damage source, or {@code null} when none can be inferred.
     * Uses the centre of the victim↔attacker bounding-box overlap (inflating the victim slightly so
     * fast projectiles that have already passed through still register). With no overlap, a
     * projectile's own position is the impact point; a distant/indirect melee attacker yields no
     * usable geometry, so the caller falls back to a weighted random part.
     */
    private static Vec3 resolveImpact(LivingEntity victim, DamageSource source) {
        Entity direct = source.getDirectEntity();
        if (direct == null) {
            // Indirect, location-based sources (e.g. explosions) carry a source position.
            return source.getSourcePosition();
        }
        AABB victimBox = victim.getBoundingBox();
        for (double inflate : new double[] {0.0, 0.3, 0.6}) {
            AABB inflated = victimBox.inflate(inflate);
            if (inflated.intersects(direct.getBoundingBox())) {
                return inflated.intersect(direct.getBoundingBox()).getCenter();
            }
        }
        return direct instanceof Projectile ? direct.position() : null;
    }

    /** Torso-biased random selection used when the hit location cannot be inferred. */
    private static BodyPart randomBiased(RandomSource random) {
        // Weights roughly proportional to silhouette area; sum = 100.
        int roll = random.nextInt(100);
        if (roll < 10) return BodyPart.HEAD;        // 10%
        if (roll < 40) return BodyPart.TORSO;       // 30%
        if (roll < 53) return BodyPart.LEFT_ARM;    // 13%
        if (roll < 66) return BodyPart.RIGHT_ARM;   // 13%
        if (roll < 78) return BodyPart.LEFT_LEG;    // 12%
        if (roll < 90) return BodyPart.RIGHT_LEG;   // 12%
        if (roll < 95) return BodyPart.LEFT_FOOT;   // 5%
        return BodyPart.RIGHT_FOOT;                 // 5%
    }

    /** Exposed for potential UI/debug use: a 0..1 vertical fraction clamped for display. */
    public static double clampFraction(double frac) {
        return Mth.clamp(frac, 0.0, 1.0);
    }
}
