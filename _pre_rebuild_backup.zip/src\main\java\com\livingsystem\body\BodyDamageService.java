package com.livingsystem.body;

import com.livingsystem.Config;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;

import java.util.List;

/**
 * Server-side logic that applies damage to a player's {@link PlayerHealthData} body-part pool:
 * per-part armour resistance, balanced splitting across multiple hit parts, and overflow into
 * neighbours (handled by {@link PlayerHealthData#hurtWithOverflow}).
 *
 * <p>This mirrors the role of LSO's {@code BodyDamageUtilInternal}, but uses a lighter resistance
 * model: instead of registering custom {@code Attribute}s and reading armour modifiers, each part
 * is simply reduced by a configurable fraction when its covering armour slot holds any item.</p>
 */
public final class BodyDamageService {

    private BodyDamageService() {
    }

    /** The armour slot that protects a given body part. */
    public static EquipmentSlot coveringSlot(BodyPart part) {
        return switch (part) {
            case HEAD -> EquipmentSlot.HEAD;
            case TORSO, LEFT_ARM, RIGHT_ARM -> EquipmentSlot.CHEST;
            case LEFT_LEG, RIGHT_LEG -> EquipmentSlot.LEGS;
            case LEFT_FOOT, RIGHT_FOOT -> EquipmentSlot.FEET;
        };
    }

    /** Fraction of damage (0..1) negated for a part by the armour currently worn over it. */
    public static float resistanceFor(Player player, BodyPart part) {
        EquipmentSlot slot = coveringSlot(part);
        if (player.getItemBySlot(slot).isEmpty()) {
            return 0.0F;
        }
        double fraction = switch (slot) {
            case HEAD -> Config.RESIST_HEAD.get();
            case CHEST -> Config.RESIST_CHEST.get();
            case LEGS -> Config.RESIST_LEGS.get();
            case FEET -> Config.RESIST_FEET.get();
            default -> 0.0;
        };
        return (float) fraction;
    }

    /**
     * Deals {@code amount} damage across the given parts (split evenly), applying each part's armour
     * resistance and spilling any excess into neighbours. Mutates {@code data} in place.
     */
    public static void applyHit(Player player, PlayerHealthData data, List<BodyPart> parts, float amount) {
        if (parts.isEmpty() || amount <= 0) {
            return;
        }
        RandomSource random = player.getRandom();
        float perPart = amount / parts.size();
        for (BodyPart part : parts) {
            float dealt = perPart * (1.0F - resistanceFor(player, part));
            data.hurtWithOverflow(part, dealt, random);
        }
    }

    /** Kills the player through vanilla's death path with a source our combat handler ignores. */
    public static void kill(ServerPlayer player) {
        player.hurt(player.damageSources().genericKill(), Float.MAX_VALUE);
    }
}
