package com.livingsystem;

import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.List;

/**
 * Common configuration for the mod, built with NeoForge's {@link ModConfigSpec}.
 *
 * <p>The resulting {@code livingsystem-common.toml} file is generated in the {@code config/}
 * folder of the game instance. Values are accessed via the {@code ConfigValue} fields below
 * after the config has been loaded.</p>
 */
public class Config {

    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    public static final ModConfigSpec.BooleanValue ENABLE_LIVING_SYSTEM = BUILDER
            .comment("Master switch for the LivingSystem mechanics.")
            .define("enableLivingSystem", true);

    public static final ModConfigSpec.IntValue TICK_INTERVAL = BUILDER
            .comment("How often (in game ticks) living systems are updated. 20 ticks = 1 second.")
            .defineInRange("tickInterval", 20, 1, 24000);

    // --- Localized body damage -------------------------------------------------------------------

    public static final ModConfigSpec.DoubleValue BODY_DAMAGE_MULTIPLIER = BUILDER
            .comment("Multiplier applied to incoming damage before it is dealt to body parts.")
            .defineInRange("bodyDamageMultiplier", 1.0, 0.0, 100.0);

    public static final ModConfigSpec.DoubleValue DERIVED_VITAL_WEIGHT = BUILDER
            .comment("How strongly the heart bar is held up by vital parts (head/torso) alone vs. limbs.",
                    "0 = the bar tracks the average of all parts; 1 = only head/torso matter for the bar.")
            .defineInRange("derivedVitalWeight", 0.5, 0.0, 1.0);

    public static final ModConfigSpec.DoubleValue RESIST_HEAD = BUILDER
            .comment("Fraction of damage to the head negated while any helmet is worn.")
            .defineInRange("resistHead", 0.10, 0.0, 1.0);

    public static final ModConfigSpec.DoubleValue RESIST_CHEST = BUILDER
            .comment("Fraction of damage to the torso/arms negated while any chestplate is worn.")
            .defineInRange("resistChest", 0.10, 0.0, 1.0);

    public static final ModConfigSpec.DoubleValue RESIST_LEGS = BUILDER
            .comment("Fraction of damage to the legs negated while any leggings are worn.")
            .defineInRange("resistLegs", 0.10, 0.0, 1.0);

    public static final ModConfigSpec.DoubleValue RESIST_FEET = BUILDER
            .comment("Fraction of damage to the feet negated while any boots are worn.")
            .defineInRange("resistFeet", 0.10, 0.0, 1.0);

    public static final ModConfigSpec.BooleanValue ENABLE_THRESHOLD_DEBUFFS = BUILDER
            .comment("Apply graduated debuffs as a body part's health drops (e.g. slowness for hurt legs).")
            .define("enableThresholdDebuffs", true);

    public static final ModConfigSpec.BooleanValue ENABLE_BLEEDING = BUILDER
            .comment("Untreated parts at/below the bleed threshold bleed the player out (damages the torso).",
                    "Off by default: with no healing items yet, a destroyed limb would otherwise be an unavoidable death spiral.")
            .define("enableBleeding", false);

    public static final ModConfigSpec.DoubleValue BLEED_THRESHOLD = BUILDER
            .comment("Health fraction (0..1) at or below which a part bleeds. 0 = only fully destroyed parts.")
            .defineInRange("bleedThreshold", 0.0, 0.0, 1.0);

    public static final ModConfigSpec.DoubleValue BLEED_RATE = BUILDER
            .comment("Damage dealt to the torso per bleeding part, per tick interval.")
            .defineInRange("bleedRate", 1.0, 0.0, 100.0);

    public static final ModConfigSpec.BooleanValue DISABLE_NATURAL_REGEN = BUILDER
            .comment("Disable vanilla natural health regeneration so the heart bar stays consistent with body parts.",
                    "Sets the naturalRegeneration gamerule false on world load.")
            .define("disableNaturalRegen", true);

    public static final ModConfigSpec.DoubleValue HEADSHOT_MULTIPLIER = BUILDER
            .comment("Extra damage multiplier for projectile hits to an unprotected head. 1.0 disables headshots.")
            .defineInRange("headshotMultiplier", 1.5, 1.0, 10.0);

    // --- Regeneration & healing ------------------------------------------------------------------

    public static final ModConfigSpec.BooleanValue ENABLE_PASSIVE_REGEN = BUILDER
            .comment("Slowly regenerate wounded (but not destroyed) body parts while well-fed.")
            .define("enablePassiveRegen", true);

    public static final ModConfigSpec.DoubleValue PASSIVE_REGEN_RATE = BUILDER
            .comment("Health restored to each wounded part per tick interval by passive regeneration.")
            .defineInRange("passiveRegenRate", 1.0, 0.0, 100.0);

    public static final ModConfigSpec.IntValue PASSIVE_REGEN_MIN_FOOD = BUILDER
            .comment("Minimum food level (0-20) required for passive regeneration to run.")
            .defineInRange("passiveRegenMinFood", 6, 0, 20);

    public static final ModConfigSpec.DoubleValue PASSIVE_REGEN_FOOD_EXHAUSTION = BUILDER
            .comment("Food exhaustion added each interval that passive regeneration heals something.")
            .defineInRange("passiveRegenFoodExhaustion", 0.5, 0.0, 40.0);

    public static final ModConfigSpec.DoubleValue SLEEP_HEAL_FRACTION = BUILDER
            .comment("Fraction of each non-destroyed part's max health restored after sleeping through the night.")
            .defineInRange("sleepHealFraction", 0.5, 0.0, 1.0);

    public static final ModConfigSpec.DoubleValue HEAL_VALUE_MAX = BUILDER
            .comment("Safety clamp on the health a single datapack healing item may apply to one part.")
            .defineInRange("healValueMax", 200.0, 0.0, 10000.0);

    public static final ModConfigSpec SPEC = BUILDER.build();
}
