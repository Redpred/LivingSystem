package com.livingsystem.body;

import com.livingsystem.LivingSystem;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.RandomSource;

import java.util.List;
import java.util.Objects;

/**
 * A single datapack-defined rule describing which body parts a given damage source strikes,
 * loaded from {@code data/<namespace>/body_damage/<source>.json}. Mirrors LSO's
 * {@code JsonBodyPartsDamageSource}.
 *
 * <p>JSON shape:</p>
 * <pre>
 * { "damage_distribution": "ALL", "body_parts": ["HEAD", "TORSO", ...] }
 * </pre>
 * {@code body_parts} may be omitted for {@code NONE}. Unknown part names are dropped with a warning.
 */
public record BodyDamageRule(DamageDistribution distribution, List<BodyPart> parts) {

    public static final Codec<BodyDamageRule> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("damage_distribution").forGetter(rule -> rule.distribution.name()),
            Codec.STRING.listOf().optionalFieldOf("body_parts", List.of())
                    .forGetter(rule -> rule.parts.stream().map(Enum::name).toList())
    ).apply(instance, BodyDamageRule::fromStrings));

    private static BodyDamageRule fromStrings(String distribution, List<String> partNames) {
        List<BodyPart> parsed = partNames.stream()
                .map(BodyDamageRule::parsePart)
                .filter(Objects::nonNull)
                .toList();
        return new BodyDamageRule(DamageDistribution.fromString(distribution), parsed);
    }

    private static BodyPart parsePart(String name) {
        try {
            return BodyPart.valueOf(name.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            LivingSystem.LOGGER.warn("Unknown body part '{}' in a body_damage rule; ignoring it.", name);
            return null;
        }
    }

    /** Resolves the concrete parts this rule hits for one event. */
    public List<BodyPart> resolve(RandomSource random) {
        return distribution.pick(random, parts);
    }
}
