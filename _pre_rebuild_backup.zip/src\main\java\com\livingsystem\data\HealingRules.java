package com.livingsystem.data;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.livingsystem.LivingSystem;
import com.livingsystem.body.HealingRule;
import com.mojang.serialization.JsonOps;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.AddReloadListenerEvent;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;

/**
 * Server-side store of datapack-defined {@link HealingRule}s, loaded from
 * {@code data/<namespace>/body_healing/*.json} and reloaded on {@code /reload}.
 *
 * <p>Keyed by the item registry id declared inside each rule's {@code "item"} field (the file name
 * is irrelevant). Server-only, like {@link BodyDamageRules}.</p>
 */
public class HealingRules extends SimpleJsonResourceReloadListener {

    private static final Gson GSON = new Gson();
    public static final String DIRECTORY = "body_healing";

    private static volatile Map<ResourceLocation, HealingRule> rules = Map.of();

    public HealingRules() {
        super(GSON, DIRECTORY);
    }

    /** Healing rule for an item id, or {@code null} if the item has none. */
    @Nullable
    public static HealingRule get(ResourceLocation itemId) {
        return rules.get(itemId);
    }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> object, ResourceManager resourceManager, ProfilerFiller profiler) {
        Map<ResourceLocation, HealingRule> loaded = new HashMap<>();
        object.forEach((location, json) -> HealingRule.CODEC
                .parse(JsonOps.INSTANCE, json)
                .resultOrPartial(error -> LivingSystem.LOGGER.error("Failed to parse body_healing rule {}: {}", location, error))
                .ifPresent(rule -> loaded.put(rule.item(), rule)));
        rules = Map.copyOf(loaded);
        LivingSystem.LOGGER.info("Loaded {} body_healing rule(s).", rules.size());
    }

    /** Registers the reload listener with the server's data-pack reload manager. */
    @EventBusSubscriber(modid = LivingSystem.MOD_ID)
    public static final class Registration {

        private Registration() {
        }

        @SubscribeEvent
        public static void onAddReloadListener(AddReloadListenerEvent event) {
            event.addListener(new HealingRules());
        }
    }
}
