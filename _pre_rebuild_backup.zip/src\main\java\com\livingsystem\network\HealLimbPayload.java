package com.livingsystem.network;

import com.livingsystem.LivingSystem;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Client -> server request to apply the player's pending single-limb heal to the chosen body part
 * (by {@link com.livingsystem.body.BodyPart#ordinal()}). The server validates against a one-shot
 * token granted when the healing item was used, so the heal value is never taken from the client.
 */
public record HealLimbPayload(int partOrdinal) implements CustomPacketPayload {

    public static final Type<HealLimbPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(LivingSystem.MOD_ID, "heal_limb"));

    public static final StreamCodec<ByteBuf, HealLimbPayload> STREAM_CODEC =
            ByteBufCodecs.VAR_INT.map(HealLimbPayload::new, HealLimbPayload::partOrdinal);

    @Override
    public Type<HealLimbPayload> type() {
        return TYPE;
    }
}
