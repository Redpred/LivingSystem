package com.livingsystem.body;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.resources.ResourceLocation;

/**
 * A datapack-defined healing behaviour bound to an item, loaded from
 * {@code data/<namespace>/body_healing/*.json}. Mirrors LSO's {@code JsonHealingConsumable}.
 *
 * <pre>
 * { "item": "minecraft:golden_apple", "heal_value": 20, "heal_time": 100,
 *   "mode": "ALL_BODY", "restores_destroyed": false }
 * </pre>
 *
 * <ul>
 *     <li>{@link Mode#ALL_BODY} — heals every eligible part when the item is used.</li>
 *     <li>{@link Mode#SINGLE_LIMB} — opens the health screen so the player treats one chosen part.</li>
 * </ul>
 * {@code restores_destroyed} permits healing a part that is at 0 (otherwise destroyed parts are skipped).
 */
public record HealingRule(ResourceLocation item, float healValue, int healTime, Mode mode, boolean restoresDestroyed) {

    public enum Mode {
        ALL_BODY,
        SINGLE_LIMB;

        public static Mode fromString(String name) {
            for (Mode mode : values()) {
                if (mode.name().equalsIgnoreCase(name)) {
                    return mode;
                }
            }
            return ALL_BODY;
        }
    }

    public static final Codec<HealingRule> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            ResourceLocation.CODEC.fieldOf("item").forGetter(HealingRule::item),
            Codec.FLOAT.fieldOf("heal_value").forGetter(HealingRule::healValue),
            Codec.INT.optionalFieldOf("heal_time", 0).forGetter(HealingRule::healTime),
            Codec.STRING.optionalFieldOf("mode", "ALL_BODY").forGetter(rule -> rule.mode.name()),
            Codec.BOOL.optionalFieldOf("restores_destroyed", false).forGetter(HealingRule::restoresDestroyed)
    ).apply(instance, (item, value, time, mode, restores) ->
            new HealingRule(item, value, time, Mode.fromString(mode), restores)));

    public boolean isSingleLimb() {
        return mode == Mode.SINGLE_LIMB;
    }
}
