package com.livingsystem.network;

import com.livingsystem.LivingSystem;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/**
 * Server -> client packet that carries the current per-body-part health for the receiving player.
 *
 * <p>Only the current-health list is transmitted; maximums are constant and known on both sides
 * (see {@code BodyPart}). The list order matches {@code BodyPart.ordinal()}.</p>
 */
public record SyncBodyHealthPayload(List<Float> health) implements CustomPacketPayload {

    public static final Type<SyncBodyHealthPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(LivingSystem.MOD_ID, "sync_body_health"));

    public static final StreamCodec<ByteBuf, SyncBodyHealthPayload> STREAM_CODEC =
            ByteBufCodecs.FLOAT.apply(ByteBufCodecs.list())
                    .map(SyncBodyHealthPayload::new, SyncBodyHealthPayload::health);

    @Override
    public Type<SyncBodyHealthPayload> type() {
        return TYPE;
    }
}
