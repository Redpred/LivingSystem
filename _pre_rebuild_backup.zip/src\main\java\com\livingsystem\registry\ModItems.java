package com.livingsystem.registry;

import com.livingsystem.LivingSystem;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Central registry for all items added by the mod.
 *
 * <p>Add new items as {@code public static final DeferredItem<Item>} fields. They are registered
 * automatically when {@link #register(IEventBus)} is called from the mod constructor.</p>
 */
public final class ModItems {

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(LivingSystem.MOD_ID);

    // Example item. Remove or replace with your own.
    public static final DeferredItem<Item> EXAMPLE_ITEM =
            ITEMS.registerSimpleItem("example_item", new Item.Properties());

    private ModItems() {}

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}
