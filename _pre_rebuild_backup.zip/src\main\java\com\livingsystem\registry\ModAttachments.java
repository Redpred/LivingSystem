package com.livingsystem.registry;

import com.livingsystem.LivingSystem;
import com.livingsystem.body.PlayerHealthData;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/**
 * Registers the mod's {@link AttachmentType data attachments}.
 *
 * <p>Attachments are NeoForge's mechanism for storing custom data on existing game objects
 * (here: the player). With a {@code serialize(...)} codec configured, the data is automatically
 * written to and read from the player's save data.</p>
 */
public final class ModAttachments {

    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES =
            DeferredRegister.create(NeoForgeRegistries.Keys.ATTACHMENT_TYPES, LivingSystem.MOD_ID);

    /** Per-body-part health for a player. Persisted to disk; reset to full on death. */
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<PlayerHealthData>> PLAYER_HEALTH =
            ATTACHMENT_TYPES.register("player_health", () -> AttachmentType
                    // Explicit lambda (not PlayerHealthData::new): the class has two constructors,
                    // which makes the method reference inexact and ambiguous between the
                    // builder(Supplier) and builder(Function<IAttachmentHolder,T>) overloads.
                    .<PlayerHealthData>builder(() -> new PlayerHealthData())
                    .serialize(PlayerHealthData.CODEC)
                    .build());

    private ModAttachments() {
    }

    public static void register(IEventBus eventBus) {
        ATTACHMENT_TYPES.register(eventBus);
    }
}
