package com.livingsystem.network;

import com.livingsystem.LivingSystem;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server -> client request to open the health screen in "heal mode" after the player used a
 * single-limb healing item. {@code restoresDestroyed} tells the UI whether destroyed limbs are
 * valid targets for this heal.
 */
public record OpenHealScreenPayload(boolean restoresDestroyed) implements CustomPacketPayload {

    public static final Type<OpenHealScreenPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(LivingSystem.MOD_ID, "open_heal_screen"));

    public static final StreamCodec<ByteBuf, OpenHealScreenPayload> STREAM_CODEC =
            ByteBufCodecs.BOOL.map(OpenHealScreenPayload::new, OpenHealScreenPayload::restoresDestroyed);

    @Override
    public Type<OpenHealScreenPayload> type() {
        return TYPE;
    }
}
