package com.livingsystem.client;

import com.livingsystem.LivingSystem;
import com.livingsystem.client.screen.HealthScreen;
import com.livingsystem.client.screen.InventoryTabs;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;

/**
 * Client-side game-bus event handling:
 * <ul>
 *     <li>Opening the {@link HealthScreen} when the bound key is pressed.</li>
 *     <li>Drawing the tab bar on top of the vanilla survival inventory and switching to the
 *     health screen when its tab is clicked.</li>
 * </ul>
 */
@EventBusSubscriber(modid = LivingSystem.MOD_ID, value = Dist.CLIENT)
public final class ClientEventHandler {

    private ClientEventHandler() {
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return;
        }
        while (ModKeyMappings.OPEN_HEALTH.consumeClick()) {
            // Only open from the in-game state (no other screen already open).
            if (minecraft.screen == null) {
                minecraft.setScreen(new HealthScreen());
            }
        }
    }

    @SubscribeEvent
    public static void onScreenRender(ScreenEvent.Render.Post event) {
        if (event.getScreen() instanceof InventoryScreen inventory) {
            InventoryTabs.render(event.getGuiGraphics(), inventory.getGuiLeft(), inventory.getGuiTop(),
                    InventoryTabs.TAB_INVENTORY, event.getMouseX(), event.getMouseY());
        }
    }

    @SubscribeEvent
    public static void onMouseClick(ScreenEvent.MouseButtonPressed.Pre event) {
        if (event.getButton() != 0) { // left click only
            return;
        }
        if (event.getScreen() instanceof InventoryScreen inventory) {
            int tab = InventoryTabs.tabAt(inventory.getGuiLeft(), inventory.getGuiTop(),
                    event.getMouseX(), event.getMouseY());
            if (tab == InventoryTabs.TAB_HEALTH) {
                Minecraft.getInstance().setScreen(new HealthScreen());
                event.setCanceled(true);
            }
        }
    }
}
