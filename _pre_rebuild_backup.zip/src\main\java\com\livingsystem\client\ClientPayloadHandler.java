package com.livingsystem.client;

import com.livingsystem.body.PlayerHealthData;
import com.livingsystem.network.OpenHealScreenPayload;
import com.livingsystem.network.SyncBodyHealthPayload;
import com.livingsystem.registry.ModAttachments;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * Handlers for incoming {@code play-to-client} payloads.
 *
 * <p>Although this lives in the {@code client} package, it must <em>not</em> reference any
 * {@code net.minecraft.client.*} type: {@code ModNetworking} (loaded on both sides) passes a method
 * reference from here to {@code registrar.playToClient}, so the dedicated server links this class
 * during {@code RegisterPayloadHandlersEvent}. The receiving player is therefore obtained from
 * {@link IPayloadContext#player()} (which is the local player on the client) rather than from
 * {@code Minecraft.getInstance()}.</p>
 */
public final class ClientPayloadHandler {

    private ClientPayloadHandler() {
    }

    public static void handleSyncBodyHealth(SyncBodyHealthPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            Player player = context.player();
            if (player != null) {
                player.setData(ModAttachments.PLAYER_HEALTH.get(),
                        PlayerHealthData.fromNetworkList(payload.health()));
            }
        });
    }

    /**
     * Opens the health screen in heal mode. The actual screen call lives in {@link ClientHooks}
     * (loaded lazily, client-only) so this class never links {@code net.minecraft.client.*} on a
     * dedicated server.
     */
    public static void handleOpenHealScreen(OpenHealScreenPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientHooks.openHealScreen(payload.restoresDestroyed()));
    }
}
