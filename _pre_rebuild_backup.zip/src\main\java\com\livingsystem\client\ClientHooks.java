package com.livingsystem.client;

import com.livingsystem.client.screen.HealthScreen;
import net.minecraft.client.Minecraft;

/**
 * Client-only entry points invoked from common code through a dist-guarded indirection.
 *
 * <p>This class is the <em>only</em> place that touches {@code net.minecraft.client.*} for the
 * healing flow. It is referenced from {@link ClientPayloadHandler} solely inside a deferred lambda,
 * so it is never loaded on a dedicated server (where the {@code play-to-client} handler never runs).
 * Keeping the screen-opening here is what prevents the "invalid dist" link crash.</p>
 */
public final class ClientHooks {

    private ClientHooks() {
    }

    public static void openHealScreen(boolean restoresDestroyed) {
        Minecraft.getInstance().setScreen(new HealthScreen(true, restoresDestroyed));
    }
}
