package com.livingsystem.body;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

import java.util.ArrayList;
import java.util.List;

/**
 * Per-player health state, holding one current-health value for each {@link BodyPart}.
 *
 * <p>Stored on the player via the data-attachment API (see {@code ModAttachments}) so it is
 * automatically persisted to disk, and synced to the owning client with a custom packet so the
 * health screen can render it.</p>
 *
 * <p>Maximum values are constant and live on {@link BodyPart}, so only the current health array
 * needs to be serialized.</p>
 */
public class PlayerHealthData {

    public static final Codec<PlayerHealthData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.FLOAT.listOf().fieldOf("health").forGetter(PlayerHealthData::toList),
            Codec.INT.listOf().optionalFieldOf("heal_remaining_ticks", List.of()).forGetter(PlayerHealthData::remainingTicksList),
            Codec.FLOAT.listOf().optionalFieldOf("heal_per_tick", List.of()).forGetter(PlayerHealthData::perTickList)
    ).apply(instance, PlayerHealthData::fromCodec));

    private final float[] health = new float[BodyPart.COUNT];
    private final int[] healRemainingTicks = new int[BodyPart.COUNT];
    private final float[] healPerTick = new float[BodyPart.COUNT];

    /** Creates a fully-healed data instance (every part at its maximum, no pending healing). */
    public PlayerHealthData() {
        for (BodyPart part : BodyPart.VALUES) {
            health[part.ordinal()] = part.getMaxHealth();
        }
    }

    /** Copy constructor. */
    public PlayerHealthData(PlayerHealthData other) {
        System.arraycopy(other.health, 0, this.health, 0, BodyPart.COUNT);
        System.arraycopy(other.healRemainingTicks, 0, this.healRemainingTicks, 0, BodyPart.COUNT);
        System.arraycopy(other.healPerTick, 0, this.healPerTick, 0, BodyPart.COUNT);
    }

    public float getHealth(BodyPart part) {
        return health[part.ordinal()];
    }

    public void setHealth(BodyPart part, float value) {
        health[part.ordinal()] = Mth.clamp(value, 0.0F, part.getMaxHealth());
    }

    /** Fraction of remaining health for a part, in {@code [0, 1]}. Useful for UI colouring. */
    public float getFraction(BodyPart part) {
        float max = part.getMaxHealth();
        return max <= 0 ? 0 : Mth.clamp(health[part.ordinal()] / max, 0.0F, 1.0F);
    }

    /** Applies damage to a single part, clamping at zero. Returns true if the part just reached 0. */
    public boolean hurt(BodyPart part, float amount) {
        if (amount <= 0) {
            return false;
        }
        float before = health[part.ordinal()];
        setHealth(part, before - amount);
        return before > 0 && health[part.ordinal()] <= 0;
    }

    /** Heals a single part, clamping at its maximum. */
    public void heal(BodyPart part, float amount) {
        if (amount <= 0) {
            return;
        }
        setHealth(part, health[part.ordinal()] + amount);
    }

    /**
     * Schedules heal-over-time on a part, blending with any in-progress schedule (LSO formula).
     * A {@code time <= 0} applies the whole value instantly. Does not itself enforce the
     * destroyed-limb policy — callers decide whether a 0-health part may be scheduled.
     */
    public void applyHealOverTime(BodyPart part, float value, int time) {
        if (value <= 0) {
            return;
        }
        if (time <= 0) {
            heal(part, value);
            return;
        }
        int i = part.ordinal();
        int remaining = healRemainingTicks[i];
        int newRemaining = time + remaining;
        healPerTick[i] = (value + remaining * healPerTick[i]) / newRemaining;
        healRemainingTicks[i] = newRemaining;
    }

    /** Advances all heal-over-time schedules by {@code ticks}. Returns true if any part healed. */
    public boolean tickHeal(int ticks) {
        boolean healed = false;
        for (BodyPart part : BodyPart.VALUES) {
            int i = part.ordinal();
            if (healRemainingTicks[i] > 0) {
                int step = Math.min(ticks, healRemainingTicks[i]);
                float amount = step * healPerTick[i];
                if (amount > 0) {
                    float before = health[i];
                    heal(part, amount);
                    if (health[i] != before) {
                        healed = true;
                    }
                }
                healRemainingTicks[i] -= step;
                if (healRemainingTicks[i] <= 0) {
                    healPerTick[i] = 0.0F;
                }
            }
        }
        return healed;
    }

    /** Total healing still pending on a part (for UI/diagnostics). */
    public float getPendingHeal(BodyPart part) {
        int i = part.ordinal();
        return healRemainingTicks[i] * healPerTick[i];
    }

    /**
     * Applies damage to a part; any amount that exceeds the part's remaining health spills into one
     * random <em>living</em> neighbour ({@link BodyPart#neighbours()}), one hop only — mirroring the
     * overflow behaviour of LSO. The spilled amount is applied raw (resistance is applied by the
     * caller before this method). Returns true if the targeted part was just destroyed.
     */
    public boolean hurtWithOverflow(BodyPart part, float amount, RandomSource random) {
        if (amount <= 0) {
            return false;
        }
        float before = health[part.ordinal()];
        float absorbed = Math.min(amount, before);
        setHealth(part, before - absorbed);
        boolean justDestroyed = before > 0 && health[part.ordinal()] <= 0;

        float excess = amount - absorbed;
        if (excess > 0) {
            List<BodyPart> living = new ArrayList<>(part.neighbours().size());
            for (BodyPart n : part.neighbours()) {
                if (health[n.ordinal()] > 0) {
                    living.add(n);
                }
            }
            if (!living.isEmpty()) {
                BodyPart spill = living.get(random.nextInt(living.size()));
                setHealth(spill, health[spill.ordinal()] - excess); // clamped at 0; further excess lost
            }
        }
        return justDestroyed;
    }

    /** True once a vital part (head or torso) has been destroyed — i.e. the player should die. */
    public boolean isVitalDestroyed() {
        return health[BodyPart.HEAD.ordinal()] <= 0 || health[BodyPart.TORSO.ordinal()] <= 0;
    }

    /**
     * Overall body condition in {@code [0, 1]} that the vanilla heart bar is derived from.
     *
     * <pre>
     * vital   = min(frac(HEAD), frac(TORSO))                 // 0 ⇒ dead
     * limbAvg = average fraction of the six non-vital parts
     * condition = vital * (k + (1-k)*limbAvg)                // k = vitalWeight
     * </pre>
     *
     * Limb damage lowers the bar but can never drive it to zero while both vital parts survive;
     * destroying head or torso forces it to zero (death).
     *
     * @param vitalWeight {@code k} in {@code [0, 1]}: how much the bar is held up by vital parts
     *                    alone versus limbs (higher = limbs matter less).
     */
    public float condition(float vitalWeight) {
        float vital = Math.min(getFraction(BodyPart.HEAD), getFraction(BodyPart.TORSO));
        float limbSum = 0.0F;
        int limbCount = 0;
        for (BodyPart part : BodyPart.VALUES) {
            if (!part.isVital()) {
                limbSum += getFraction(part);
                limbCount++;
            }
        }
        float limbAvg = limbCount == 0 ? 1.0F : limbSum / limbCount;
        float k = Mth.clamp(vitalWeight, 0.0F, 1.0F);
        return Mth.clamp(vital * (k + (1.0F - k) * limbAvg), 0.0F, 1.0F);
    }

    /** The vanilla health value the heart bar should show, given a max health and vital weight. */
    public float derivedHealth(float maxHealth, float vitalWeight) {
        return maxHealth * condition(vitalWeight);
    }

    /** True if no part has been destroyed (all parts above zero). */
    public boolean isFullyAlive() {
        for (BodyPart part : BodyPart.VALUES) {
            if (health[part.ordinal()] <= 0) {
                return false;
            }
        }
        return true;
    }

    // --- (de)serialization helpers -------------------------------------------------------------

    private List<Float> toList() {
        List<Float> list = new ArrayList<>(BodyPart.COUNT);
        for (float v : health) {
            list.add(v);
        }
        return list;
    }

    private List<Integer> remainingTicksList() {
        List<Integer> list = new ArrayList<>(BodyPart.COUNT);
        for (int v : healRemainingTicks) {
            list.add(v);
        }
        return list;
    }

    private List<Float> perTickList() {
        List<Float> list = new ArrayList<>(BodyPart.COUNT);
        for (float v : healPerTick) {
            list.add(v);
        }
        return list;
    }

    public List<Float> toNetworkList() {
        return toList();
    }

    /** Codec factory: {@code health} is required; the heal-over-time arrays are optional (old saves). */
    private static PlayerHealthData fromCodec(List<Float> healthList, List<Integer> remaining, List<Float> perTick) {
        PlayerHealthData data = new PlayerHealthData();
        for (int i = 0; i < BodyPart.COUNT && i < healthList.size(); i++) {
            data.health[i] = Mth.clamp(healthList.get(i), 0.0F, BodyPart.VALUES[i].getMaxHealth());
        }
        for (int i = 0; i < BodyPart.COUNT && i < remaining.size(); i++) {
            data.healRemainingTicks[i] = Math.max(0, remaining.get(i));
        }
        for (int i = 0; i < BodyPart.COUNT && i < perTick.size(); i++) {
            data.healPerTick[i] = Math.max(0.0F, perTick.get(i));
        }
        return data;
    }

    public static PlayerHealthData fromNetworkList(List<Float> list) {
        PlayerHealthData data = new PlayerHealthData();
        for (int i = 0; i < BodyPart.COUNT && i < list.size(); i++) {
            data.health[i] = Mth.clamp(list.get(i), 0.0F, BodyPart.VALUES[i].getMaxHealth());
        }
        return data;
    }
}
