package com.livingsystem.client.screen;

import com.livingsystem.body.BodyPart;
import com.livingsystem.body.PlayerHealthData;
import com.livingsystem.client.ModKeyMappings;
import com.livingsystem.network.HealLimbPayload;
import com.livingsystem.registry.ModAttachments;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * The "Health" tab screen. Mirrors the size and tab bar of the vanilla inventory window.
 *
 * <p>The top-left quarter shows a minimalist, Minecraft-styled humanoid built from eight coloured
 * blocks (head, torso, both arms, both legs, both feet). Each block is tinted from green (healthy)
 * through yellow to red (critical) based on that part's remaining health, and hovering a block shows
 * its exact value. The right half lists every part with a small bar for quick reading.</p>
 */
public class HealthScreen extends Screen {

    private static final int W = 176;
    private static final int H = 166;

    private static final int COLOR_PANEL_BORDER = 0xFF000000;
    private static final int COLOR_PANEL = 0xFFC6C6C6;
    private static final int COLOR_TEXT = 0x404040;
    private static final int COLOR_BLOCK_BORDER = 0xFF1A1A1A;
    private static final int COLOR_DESTROYED = 0xFF303030;

    private int leftPos;
    private int topPos;

    private final Map<BodyPart, Rect> blocks = new EnumMap<>(BodyPart.class);
    private BodyPart hovered;

    /** When true, clicking a body part sends a heal request instead of doing nothing. */
    private final boolean healMode;
    /** In heal mode, whether the pending heal may target a destroyed (0-health) limb. */
    private final boolean restoresDestroyed;

    public HealthScreen() {
        this(false, false);
    }

    public HealthScreen(boolean healMode, boolean restoresDestroyed) {
        super(Component.translatable("screen.livingsystem.health"));
        this.healMode = healMode;
        this.restoresDestroyed = restoresDestroyed;
    }

    @Override
    protected void init() {
        this.leftPos = (this.width - W) / 2;
        this.topPos = (this.height - H) / 2;
        layoutFigure();
    }

    /** Places the eight blocks in the top-left quarter of the window, relative to {@code leftPos/topPos}. */
    private void layoutFigure() {
        blocks.clear();
        int cx = leftPos + 44; // centre of the left-hand quarter (width 88)
        blocks.put(BodyPart.HEAD, new Rect(cx - 6, topPos + 20, 12, 12));
        blocks.put(BodyPart.TORSO, new Rect(cx - 8, topPos + 33, 16, 24));
        blocks.put(BodyPart.LEFT_ARM, new Rect(cx - 16, topPos + 33, 6, 22));
        blocks.put(BodyPart.RIGHT_ARM, new Rect(cx + 10, topPos + 33, 6, 22));
        blocks.put(BodyPart.LEFT_LEG, new Rect(cx - 8, topPos + 58, 7, 18));
        blocks.put(BodyPart.RIGHT_LEG, new Rect(cx + 1, topPos + 58, 7, 18));
        blocks.put(BodyPart.LEFT_FOOT, new Rect(cx - 8, topPos + 77, 7, 7));
        blocks.put(BodyPart.RIGHT_FOOT, new Rect(cx + 1, topPos + 77, 7, 7));
    }

    private PlayerHealthData data() {
        Player player = this.minecraft != null ? this.minecraft.player : null;
        return player != null ? player.getData(ModAttachments.PLAYER_HEALTH.get()) : new PlayerHealthData();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);

        // Window panel.
        graphics.fill(leftPos - 1, topPos - 1, leftPos + W + 1, topPos + H + 1, COLOR_PANEL_BORDER);
        graphics.fill(leftPos, topPos, leftPos + W, topPos + H, COLOR_PANEL);

        // Tab bar (health tab selected).
        InventoryTabs.render(graphics, leftPos, topPos, InventoryTabs.TAB_HEALTH, mouseX, mouseY);

        graphics.drawString(this.font, this.title, leftPos + 8, topPos + 6, COLOR_TEXT, false);

        PlayerHealthData data = data();
        renderFigure(graphics, data, mouseX, mouseY);
        renderList(graphics, data);

        if (healMode) {
            graphics.drawString(this.font, Component.translatable("screen.livingsystem.heal_prompt"),
                    leftPos + 8, topPos + H - 12, COLOR_TEXT, false);
        }

        if (hovered != null) {
            graphics.renderComponentTooltip(this.font, tooltipFor(hovered, data), mouseX, mouseY);
        }
    }

    private void renderFigure(GuiGraphics graphics, PlayerHealthData data, int mouseX, int mouseY) {
        hovered = null;
        for (Map.Entry<BodyPart, Rect> entry : blocks.entrySet()) {
            BodyPart part = entry.getKey();
            Rect r = entry.getValue();
            boolean isHover = r.contains(mouseX, mouseY);
            if (isHover) {
                hovered = part;
            }
            int border = isHover ? 0xFFFFFFFF : COLOR_BLOCK_BORDER;
            graphics.fill(r.x - 1, r.y - 1, r.x + r.w + 1, r.y + r.h + 1, border);
            graphics.fill(r.x, r.y, r.x + r.w, r.y + r.h, colorFor(data, part));
        }
    }

    private void renderList(GuiGraphics graphics, PlayerHealthData data) {
        int x = leftPos + 92;
        int barWidth = 76;
        for (int i = 0; i < BodyPart.COUNT; i++) {
            BodyPart part = BodyPart.VALUES[i];
            int y = topPos + 16 + i * 18; // pitch tightened so all eight parts fit the window
            graphics.drawString(this.font, Component.translatable(part.translationKey()), x, y, COLOR_TEXT, false);

            int barY = y + 9;
            graphics.fill(x, barY, x + barWidth, barY + 4, 0xFF555555);
            int filled = (int) (barWidth * data.getFraction(part));
            graphics.fill(x, barY, x + filled, barY + 4, colorFor(data, part));
        }
    }

    private List<Component> tooltipFor(BodyPart part, PlayerHealthData data) {
        List<Component> lines = new ArrayList<>(2);
        lines.add(Component.translatable(part.translationKey()));
        lines.add(Component.literal(String.format("%.0f / %.0f", data.getHealth(part), part.getMaxHealth())));
        return lines;
    }

    /** Green -> yellow -> red gradient, with destroyed parts rendered dark grey. */
    private static int colorFor(PlayerHealthData data, BodyPart part) {
        if (data.getHealth(part) <= 0) {
            return COLOR_DESTROYED;
        }
        float frac = data.getFraction(part);
        float red;
        float green;
        if (frac > 0.5F) {
            red = (1.0F - frac) * 2.0F;
            green = 1.0F;
        } else {
            red = 1.0F;
            green = frac * 2.0F;
        }
        int r = Mth.clamp((int) (red * 255), 0, 255);
        int g = Mth.clamp((int) (green * 255), 0, 255);
        return 0xFF000000 | (r << 16) | (g << 8);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int tab = InventoryTabs.tabAt(leftPos, topPos, mouseX, mouseY);
            if (tab == InventoryTabs.TAB_INVENTORY) {
                openInventory();
                return true;
            }
            if (tab == InventoryTabs.TAB_HEALTH) {
                return true; // already here
            }

            if (healMode) {
                PlayerHealthData data = data();
                for (Map.Entry<BodyPart, Rect> entry : blocks.entrySet()) {
                    if (entry.getValue().contains(mouseX, mouseY)) {
                        BodyPart part = entry.getKey();
                        boolean destroyed = data.getHealth(part) <= 0;
                        if (destroyed && !restoresDestroyed) {
                            return true; // this treatment cannot restore a destroyed limb
                        }
                        PacketDistributor.sendToServer(new HealLimbPayload(part.ordinal()));
                        this.onClose();
                        return true;
                    }
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.minecraft != null
                && this.minecraft.options.keyInventory.matches(keyCode, scanCode)) {
            this.onClose();
            return true;
        }
        if (ModKeyMappings.OPEN_HEALTH.matches(keyCode, scanCode)) {
            this.onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void openInventory() {
        if (this.minecraft != null && this.minecraft.player != null) {
            this.minecraft.setScreen(new InventoryScreen(this.minecraft.player));
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** Simple integer rectangle for block layout / hit testing. */
    private record Rect(int x, int y, int w, int h) {
        boolean contains(double px, double py) {
            return px >= x && px < x + w && py >= y && py < y + h;
        }
    }
}
