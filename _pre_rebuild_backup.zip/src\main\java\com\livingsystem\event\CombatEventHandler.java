package com.livingsystem.event;

import com.livingsystem.Config;
import com.livingsystem.LivingSystem;
import com.livingsystem.body.BodyDamageRule;
import com.livingsystem.body.BodyDamageService;
import com.livingsystem.body.BodyPart;
import com.livingsystem.body.BodyPartLocator;
import com.livingsystem.body.DamageDistribution;
import com.livingsystem.body.PlayerHealthData;
import com.livingsystem.data.BodyDamageRules;
import com.livingsystem.network.ModNetworking;
import com.livingsystem.registry.ModAttachments;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

import java.util.List;

/**
 * Routes incoming player damage into the <em>authoritative</em> per-body-part health pool, then
 * makes the vanilla heart bar reflect that pool.
 *
 * <p>Body parts are the real life total. For every relevant hit we: resolve which parts are struck
 * (datapack rules, else the geometric {@link BodyPartLocator}), deal the damage to those parts (with
 * armour resistance and neighbour overflow), then hand vanilla exactly the heart loss derived from
 * the new part state — zeroing vanilla's own mitigation so our figure is applied verbatim. Vanilla
 * still performs the hurt animation, sound, i-frames and (when a vital part is destroyed) the death,
 * so the rest of the game keeps working normally.</p>
 */
@EventBusSubscriber(modid = LivingSystem.MOD_ID)
public final class CombatEventHandler {

    private CombatEventHandler() {
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!Config.ENABLE_LIVING_SYSTEM.get()) {
            return;
        }
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        if (player.isCreative() || player.isSpectator()) {
            return;
        }

        DamageSource source = event.getSource();
        // Our own lethal/void damage must reach vanilla untouched (also prevents re-entry).
        if (source.is(DamageTypes.GENERIC_KILL) || source.is(DamageTypes.FELL_OUT_OF_WORLD)) {
            return;
        }

        float incoming = event.getAmount();
        if (incoming <= 0) {
            return;
        }

        PlayerHealthData data = player.getData(ModAttachments.PLAYER_HEALTH.get());
        List<BodyPart> parts = resolveParts(player, source);

        float amount = incoming * Config.BODY_DAMAGE_MULTIPLIER.get().floatValue();
        amount *= headshotMultiplier(player, source, parts);

        BodyDamageService.applyHit(player, data, parts, amount);

        player.setData(ModAttachments.PLAYER_HEALTH.get(), data);
        ModNetworking.sendTo(player, data);

        // Make vanilla apply exactly the heart loss derived from the new part state.
        float derived = data.derivedHealth(player.getMaxHealth(), Config.DERIVED_VITAL_WEIGHT.get().floatValue());
        float current = player.getHealth();
        float desiredLoss = data.isVitalDestroyed() ? current : Mth.clamp(current - derived, 0.0F, current);

        event.setAmount(desiredLoss);
        for (DamageContainer.Reduction reduction : DamageContainer.Reduction.values()) {
            event.addReductionModifier(reduction, (container, reductionIn) -> 0.0F);
        }

        LivingSystem.LOGGER.debug("{} took {} ({} dmg) -> parts {}; hearts -{}",
                player.getGameProfile().getName(), source.getMsgId(), amount, parts, desiredLoss);
    }

    /** Datapack rule for the source, else a single geometric hit location. NONE → internal (torso). */
    private static List<BodyPart> resolveParts(ServerPlayer player, DamageSource source) {
        BodyDamageRule rule = BodyDamageRules.get(source.getMsgId());
        if (rule != null) {
            if (rule.distribution() == DamageDistribution.NONE) {
                return List.of(BodyPart.TORSO);
            }
            List<BodyPart> resolved = rule.resolve(player.getRandom());
            if (!resolved.isEmpty()) {
                return resolved;
            }
        }
        return List.of(BodyPartLocator.locate(player, source));
    }

    /** Extra multiplier for a projectile striking an unprotected head. */
    private static float headshotMultiplier(ServerPlayer player, DamageSource source, List<BodyPart> parts) {
        double multiplier = Config.HEADSHOT_MULTIPLIER.get();
        if (multiplier > 1.0
                && source.is(DamageTypeTags.IS_PROJECTILE)
                && parts.contains(BodyPart.HEAD)
                && player.getItemBySlot(EquipmentSlot.HEAD).isEmpty()) {
            return (float) multiplier;
        }
        return 1.0F;
    }
}
