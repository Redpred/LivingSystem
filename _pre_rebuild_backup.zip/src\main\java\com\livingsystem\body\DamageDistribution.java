package com.livingsystem.body;

import net.minecraft.util.RandomSource;

import java.util.List;

/**
 * How a damage source's configured body-part list is turned into the actual parts hit.
 *
 * <ul>
 *     <li>{@link #NONE} — the source is not localized (it is routed to the torso as internal damage
 *     by the combat handler so it still flows through the part model).</li>
 *     <li>{@link #ONE_OF} — exactly one of the listed parts, chosen at random.</li>
 *     <li>{@link #ALL} — every listed part (the incoming damage is split between them).</li>
 * </ul>
 *
 * Mirrors LSO's {@code DamageDistributionEnum}.
 */
public enum DamageDistribution {
    NONE,
    ONE_OF,
    ALL;

    /** Case-insensitive parse used by {@link BodyDamageRule}'s codec; defaults to {@link #ONE_OF}. */
    public static DamageDistribution fromString(String name) {
        for (DamageDistribution d : values()) {
            if (d.name().equalsIgnoreCase(name)) {
                return d;
            }
        }
        return ONE_OF;
    }

    /** Resolves the concrete parts to hit from a configured list. */
    public List<BodyPart> pick(RandomSource random, List<BodyPart> parts) {
        if (parts.isEmpty()) {
            return List.of();
        }
        return switch (this) {
            case NONE -> List.of();
            case ONE_OF -> List.of(parts.get(random.nextInt(parts.size())));
            case ALL -> parts;
        };
    }
}
