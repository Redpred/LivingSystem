package com.livingsystem.event;

import com.livingsystem.Config;
import com.livingsystem.body.BodyDamageService;
import com.livingsystem.body.BodyPart;
import com.livingsystem.body.PlayerHealthData;
import com.livingsystem.network.ModNetworking;
import com.livingsystem.registry.ModAttachments;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.GameRules;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.level.LevelEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

import com.livingsystem.LivingSystem;

/**
 * The periodic server-side upkeep for localized body damage:
 * <ol>
 *     <li>item heal-over-time and food-gated passive regeneration of wounded parts,</li>
 *     <li>graduated debuffs as parts get low (replaces v1's destroy-only reaction),</li>
 *     <li>optional bleeding from untreated parts (damages the torso),</li>
 *     <li>making the vanilla heart bar track the part-derived value (both damage and healing), and
 *     killing the player when a vital part is gone.</li>
 * </ol>
 * Vanilla natural regeneration is disabled on world load — healing is driven by the mod's own
 * heal-over-time, passive regen and sleep recovery instead.
 */
@EventBusSubscriber(modid = LivingSystem.MOD_ID)
public final class LivingTickHandler {

    private LivingTickHandler() {
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!Config.ENABLE_LIVING_SYSTEM.get()) {
            return;
        }
        if (!(event.getEntity() instanceof ServerPlayer player) || player.isCreative() || player.isSpectator()) {
            return;
        }
        int interval = Config.TICK_INTERVAL.get();
        if (player.tickCount % interval != 0) {
            return;
        }

        PlayerHealthData data = player.getData(ModAttachments.PLAYER_HEALTH.get());
        boolean changed = false;

        // Advance item heal-over-time, then food-gated passive regeneration of wounded parts.
        changed |= data.tickHeal(interval);
        if (Config.ENABLE_PASSIVE_REGEN.get()) {
            changed |= applyPassiveRegen(player, data);
        }

        if (Config.ENABLE_THRESHOLD_DEBUFFS.get()) {
            applyThresholdDebuffs(player, data, interval);
        }

        if (Config.ENABLE_BLEEDING.get()) {
            changed |= applyBleeding(player, data);
        }

        if (data.isVitalDestroyed()) {
            BodyDamageService.kill(player);
            return;
        }

        // The heart bar tracks the part-derived value in both directions (damage and healing).
        float derived = data.derivedHealth(player.getMaxHealth(), Config.DERIVED_VITAL_WEIGHT.get().floatValue());
        player.setHealth(Mth.clamp(derived, 0.0F, player.getMaxHealth()));

        if (changed) {
            player.setData(ModAttachments.PLAYER_HEALTH.get(), data);
            ModNetworking.sendTo(player, data);
        }
    }

    /** Food-gated passive regeneration of wounded (but not destroyed) parts. */
    private static boolean applyPassiveRegen(ServerPlayer player, PlayerHealthData data) {
        if (player.getFoodData().getFoodLevel() <= Config.PASSIVE_REGEN_MIN_FOOD.get()) {
            return false;
        }
        float rate = Config.PASSIVE_REGEN_RATE.get().floatValue();
        if (rate <= 0) {
            return false;
        }
        boolean healed = false;
        for (BodyPart part : BodyPart.VALUES) {
            float health = data.getHealth(part);
            if (health > 0 && health < part.getMaxHealth()) { // destroyed parts need treatment, not rest
                data.heal(part, rate);
                healed = true;
            }
        }
        if (healed) {
            player.getFoodData().addExhaustion(Config.PASSIVE_REGEN_FOOD_EXHAUSTION.get().floatValue());
        }
        return healed;
    }

    /** Bleeds the torso once per interval for each non-vital part at/below the bleed threshold. */
    private static boolean applyBleeding(ServerPlayer player, PlayerHealthData data) {
        float threshold = Config.BLEED_THRESHOLD.get().floatValue();
        int bleeders = 0;
        for (BodyPart part : BodyPart.VALUES) {
            if (!part.isVital() && data.getFraction(part) <= threshold) {
                bleeders++;
            }
        }
        if (bleeders == 0) {
            return false;
        }
        data.hurtWithOverflow(BodyPart.TORSO, Config.BLEED_RATE.get().floatValue() * bleeders, player.getRandom());
        return true;
    }

    private static void applyThresholdDebuffs(ServerPlayer player, PlayerHealthData data, int interval) {
        int duration = interval * 2 + 20; // re-applied each interval; lapses when no longer refreshed

        float head = data.getFraction(BodyPart.HEAD);
        if (head < 0.25F) {
            add(player, MobEffects.BLINDNESS, 0, duration);
        } else if (head < 0.5F) {
            add(player, MobEffects.CONFUSION, 0, duration);
        }

        float torso = data.getFraction(BodyPart.TORSO);
        if (torso < 0.25F) {
            add(player, MobEffects.WEAKNESS, 1, duration);
        } else if (torso < 0.5F) {
            add(player, MobEffects.WEAKNESS, 0, duration);
        }

        float arms = Math.min(data.getFraction(BodyPart.LEFT_ARM), data.getFraction(BodyPart.RIGHT_ARM));
        if (arms < 0.25F) {
            add(player, MobEffects.DIG_SLOWDOWN, 1, duration);
        } else if (arms < 0.5F) {
            add(player, MobEffects.DIG_SLOWDOWN, 0, duration);
        }

        float lower = Math.min(
                Math.min(data.getFraction(BodyPart.LEFT_LEG), data.getFraction(BodyPart.RIGHT_LEG)),
                Math.min(data.getFraction(BodyPart.LEFT_FOOT), data.getFraction(BodyPart.RIGHT_FOOT)));
        if (lower < 0.25F) {
            add(player, MobEffects.MOVEMENT_SLOWDOWN, 1, duration);
        } else if (lower < 0.5F) {
            add(player, MobEffects.MOVEMENT_SLOWDOWN, 0, duration);
        }
    }

    private static void add(ServerPlayer player, Holder<MobEffect> effect, int amplifier, int duration) {
        player.addEffect(new MobEffectInstance(effect, duration, amplifier, false, false, true));
    }

    @SubscribeEvent
    public static void onLevelLoad(LevelEvent.Load event) {
        if (!Config.DISABLE_NATURAL_REGEN.get()) {
            return;
        }
        if (event.getLevel() instanceof ServerLevel level) {
            GameRules.BooleanValue rule = level.getGameRules().getRule(GameRules.RULE_NATURAL_REGENERATION);
            if (rule.get()) {
                rule.set(false, level.getServer());
            }
        }
    }
}
