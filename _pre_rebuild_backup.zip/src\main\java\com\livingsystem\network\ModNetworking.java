package com.livingsystem.network;

import com.livingsystem.LivingSystem;
import com.livingsystem.body.PlayerHealthData;
import com.livingsystem.client.ClientPayloadHandler;
import com.livingsystem.event.HealingHandler;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Registers the mod's network payloads and provides helpers for sending them.
 *
 * <p>Runs on the mod event bus (both physical sides). The {@code ClientPayloadHandler} reference
 * below is only ever <em>invoked</em> on the client, so the dedicated server never touches
 * client-only classes.</p>
 */
@EventBusSubscriber(modid = LivingSystem.MOD_ID)
public final class ModNetworking {

    /** Bump this when the wire format of any payload changes incompatibly. */
    private static final String PROTOCOL_VERSION = "3";

    private ModNetworking() {
    }

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(PROTOCOL_VERSION);
        registrar.playToClient(
                SyncBodyHealthPayload.TYPE,
                SyncBodyHealthPayload.STREAM_CODEC,
                ClientPayloadHandler::handleSyncBodyHealth);
        registrar.playToClient(
                OpenHealScreenPayload.TYPE,
                OpenHealScreenPayload.STREAM_CODEC,
                ClientPayloadHandler::handleOpenHealScreen);
        registrar.playToServer(
                HealLimbPayload.TYPE,
                HealLimbPayload.STREAM_CODEC,
                HealingHandler::handleHealLimb);
    }

    /** Sends the player's current body-part health to their own client. */
    public static void sendTo(ServerPlayer player, PlayerHealthData data) {
        PacketDistributor.sendToPlayer(player, new SyncBodyHealthPayload(data.toNetworkList()));
    }

    /** Asks the player's client to open the health screen in heal mode. */
    public static void sendOpenHealScreen(ServerPlayer player, boolean restoresDestroyed) {
        PacketDistributor.sendToPlayer(player, new OpenHealScreenPayload(restoresDestroyed));
    }
}
